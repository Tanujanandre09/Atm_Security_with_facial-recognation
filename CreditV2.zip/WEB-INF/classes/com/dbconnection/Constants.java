package com.dbconnection;

public class Constants {

	public static final int accountNumber = 1234;
	
	public static final String WORKSPACE_PATH = "D:\\Workspace1\\CreditV2";
	
	public static final String IMAGE_FILE_PATH = "D:\\Workspace1\\CreditV2\\";

	public static final String APP_PATH_2 = "D:\\Workspace1\\CreditV2\\";

}
