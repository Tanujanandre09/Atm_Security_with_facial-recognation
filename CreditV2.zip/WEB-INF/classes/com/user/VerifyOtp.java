package com.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dbconnection.DbConnection;

/**
 * Servlet implementation class VerifyOtp
 */
@WebServlet("/VerifyOtp")
public class VerifyOtp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VerifyOtp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
		try{
			String bttn =request.getParameter("password");
			
			System.out.println("entered otp : "+bttn);
			
			HttpSession session = request.getSession();
//			String org_otp=(String)session.getAttribute("otp");
//			System.out.println("orignl otp is "+org_otp);
			
//			String fst_otp=org_otp.substring(0, 4);
//			System.out.println("fst_otp "+fst_otp);
			
			////
			
			String accNum=(String)session.getAttribute("accNum");
			System.out.println("login for : "+accNum);

			Connection con = DbConnection.getConnection();
			Statement st = con.createStatement();
			System.out.println("l1");
			ResultSet rs = st.executeQuery("select * from users where account_number='"+accNum+"'");
			System.out.println("l2");
			if(rs.next()){
				System.out.println("l3");
//				String email = rs.getString("email");
				String user_id = rs.getString("id");
				String p = rs.getString("password");
				
				if(bttn.equalsIgnoreCase(p)){
					
					
					session.setAttribute("accNum", accNum);
					session.setAttribute("userId", user_id);
					session.setAttribute("type", "user");
					response.sendRedirect("GuestVerified.jsp");
					
				}else{
					
					response.sendRedirect("showKeypad.jsp?user='incorrect'");
				}
			}
			////
			
			System.out.print("button value    " +bttn);
			
			}catch(Exception e)
			{
				e.printStackTrace();
			}

		
	}

}
