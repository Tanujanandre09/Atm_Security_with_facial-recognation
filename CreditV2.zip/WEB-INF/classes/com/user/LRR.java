package com.user;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dbconnection.Constants;
import com.dbconnection.DbConnection;

/**
 * Servlet implementation class LRR
 */
@WebServlet("/LRR")
public class LRR extends HttpServlet {

	private static final long serialVersionUID = 1L;
	float per;
	int countA = 0, countB = 0;
	String checkimage = "D:\\WebTest111.jpg";
	String nextpageimage;
	String adminimage, imagetext, admincheck;
	String year;
	String roll_no;
	Connection con = null;
	float x;
	String p;
	String name;

	public void init() {

		try {
			con = DbConnection.getConnection();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LRR() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("Post");

		try {

			PreparedStatement ps = con.prepareStatement("select * from users ");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println("-------------------------------------");
				adminimage = rs.getString("profile_picture");
				imagetext = rs.getString("profile_picture");
				String userId = rs.getString("id");

				System.out.println(adminimage);
				System.out.println(imagetext);

				admincheck = Constants.IMAGE_FILE_PATH + adminimage;
				// System.out.println(admincheck);

				System.out.println(" files  : " + checkimage + " : " + admincheck);

				float l = compareimage(checkimage, admincheck);

				System.out.println(l);

				PreparedStatement ps6 = con.prepareStatement("update users set mvalue=? where id = ? ");
				ps6.setString(1, String.valueOf(l));
				ps6.setString(2, userId);
				ps6.executeUpdate();

			} // -----------------------------end of
				// while----------------------------

			PreparedStatement ps7 = con.prepareStatement("select max(mvalue) as per from users ");
			ResultSet rs7 = ps7.executeQuery();
			while (rs7.next()) {
				per = rs7.getFloat("per");
			}

			HttpSession session = request.getSession();

			String detectedUserId = "";
			PreparedStatement ps8 = con.prepareStatement("select * from users where mvalue=?");
			ps8.setFloat(1, per);
			ResultSet rs8 = ps8.executeQuery();
			while (rs8.next()) {
				detectedUserId = rs8.getString("id");
				System.out.println("diseaseId =" + detectedUserId);
				// response.sendRedirect("nameretrive.jsp");
			}

			String userId = session.getAttribute("userId").toString();

			if (per > 60 && detectedUserId.equalsIgnoreCase(userId)) {
				response.sendRedirect("CustomerHome.jsp?Account Details varified successfully.");
			}

			response.sendRedirect("CustomerHome.jsp?Face is not Matching...");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public float compareimage(String img1, String img2) {
		try {

			File file1 = new File(img1);
			BufferedImage image = ImageIO.read(file1);
			int width = image.getWidth(null);
			int height = image.getHeight(null);
			int[][] clr = new int[width][height];

			File files = new File(img2);
			BufferedImage images = ImageIO.read(files);
			int widthe = images.getWidth(null);
			int heighte = images.getHeight(null);
			int[][] clre = new int[widthe][heighte];

			int smw = 0;
			int smh = 0;
			int p = 0;
			// CALUCLATING THE SMALLEST VALUE AMONG WIDTH AND HEIGHT
			if (width > widthe) {
				smw = widthe;
			} else {
				smw = width;
			}
			if (height > heighte) {
				smh = heighte;
			} else {
				smh = height;
			}
			// CHECKING NUMBER OF PIXELS SIMILARITY
			for (int a = 0; a < smw; a++) {
				for (int b = 0; b < smh; b++) {
					clre[a][b] = images.getRGB(a, b);
					clr[a][b] = image.getRGB(a, b);
					if (clr[a][b] == clre[a][b]) {
						p = p + 1;
					}
				}
			}

			float w, h = 0;
			if (width > widthe) {
				w = width;
			} else {
				w = widthe;
			}
			if (height > heighte) {
				h = height;
			} else {
				h = heighte;
			}
			float s = (smw * smh);
			// CALUCLATING PERCENTAGE
			x = ((100 * p) / s);
			// System.out.println("Only x= "+x);
			// System.out.println("THE PERCENTAGE SIMILARITY IS APPROXIMATELY
			// ="+x+"%");

		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return x;
	}

	public void distroy() {

		try {

			con.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

}
