package com.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.Collections;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dbconnection.DbConnection;

/**
 * Servlet implementation class GuestWithdrawRequest
 */
@WebServlet("/GuestWithdrawRequest")
public class GuestWithdrawRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GuestWithdrawRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			String accNum = request.getParameter("accNum");
			String password = request.getParameter("password");

			System.out.println(" ---- > " + accNum + " " + password);

			Connection con = DbConnection.getConnection();

			PreparedStatement ps = con.prepareStatement("select * from USERS where account_number='" + accNum + "'");
			ResultSet rs = ps.executeQuery();

			System.out.println("1");

			if (rs.next()) {
				HttpSession session = request.getSession();
				session.setAttribute("userId", rs.getString("id"));
				session.setAttribute("accNum", accNum);
				session.setAttribute("fullname", rs.getString("fullname"));
				session.setAttribute("profilePicture", rs.getString("profile_picture"));

				String email = rs.getString("email");

				System.out.println("2 : " + rs.getString("id"));

				String userId = rs.getString("id");

				System.out.println("3 : " + userId);

				/// random

				Integer[] arr = new Integer[10];

				for (int i = 0; i < arr.length; i++) {
					arr[i] = i;
				}
				Collections.shuffle(Arrays.asList(arr));

				for (int i = 0; i < arr.length; i++) {
					System.out.print(arr[i] + " ");
				}

				String str = Arrays.toString(arr);
				String str1 = str.toString().replace("[", "").replace("]", "").replace(", ", "");

				session.setAttribute("str1", str1);
				///

				String otp = StringRandomGen.generateRandomDigits();

				session.setAttribute("otp", otp);

				System.out.println("otp : "+otp);
				
				String message = "Hi " + rs.getString("fullname")
						+ " <br><br> We have received request for withdraw money please share below OTP for transaction with your trusted person : "
						+ otp + "<br><br>" + "<br><br>";

				PreparedStatement ps2 = con
						.prepareStatement("UPDATE `users` " + " set otp = '" + otp + "' where id = '" + userId + "' ");

				int rst = ps2.executeUpdate();

				if (rst > 0) {

					Mailer.EmailSending(email, "password", message);

					response.sendRedirect("OtpVerify.jsp?otpVerify");

				} else {
					response.sendRedirect("CustomerHome.jsp?incorrectAccNum");
				}
				System.out.println("3");

			} else {
				response.sendRedirect("CustomerHome.jsp?incorrectAccNum");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}