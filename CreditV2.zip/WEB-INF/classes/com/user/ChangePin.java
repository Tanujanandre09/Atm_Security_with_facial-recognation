package com.user;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dbconnection.DbConnection;

/**
 * Servlet implementation class ChangePin
 */
@WebServlet("/ChangePin")
public class ChangePin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ChangePin() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {

			String accountNumber = request.getParameter("accNum");

			String currentPin = request.getParameter("currentPin");

			String newPin = request.getParameter("newPing");

			System.out.println("acn : " + accountNumber + " currentpin : " + currentPin + " newpin : " + newPin);

			Connection con = DbConnection.getConnection();

			PreparedStatement ps = con.prepareStatement("select * from users where account_number='" + accountNumber
					+ "' and password = '" + currentPin + "'");

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {

				System.out.println("userId : " + rs.getString("id"));

				PreparedStatement pst = con.prepareStatement("UPDATE users set password = ? where id = ?");
				pst.setString(1, newPin);
				pst.setString(2, rs.getString("id"));

				int r = pst.executeUpdate();
				
				if(r>0){
					response.sendRedirect("CustomerHome.jsp?success");
				}else{
					response.sendRedirect("ChangePin.jsp?changePinFailed");
				}
			} else {
				response.sendRedirect("ChangePin.jsp?invalidUser");
			}

		} catch (Exception e) {
			e.printStackTrace();
			// response.sendRedirect("ViewUsers.jsp?incorrectAmount");
		}
	}
}