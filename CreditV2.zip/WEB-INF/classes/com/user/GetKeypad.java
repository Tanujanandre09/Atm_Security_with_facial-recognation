package com.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GetKeypad
 */
@WebServlet("/GetKeypad")
public class GetKeypad extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetKeypad() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			String bttn = request.getParameter("otp");

			System.out.println("entered otp : " + bttn);

			HttpSession session = request.getSession();
			String org_otp = (String) session.getAttribute("otp");
			System.out.println("orignl otp is " + org_otp);

			String fst_otp = org_otp.substring(0, 4);
			System.out.println("fst_otp " + fst_otp);

			System.out.print("button value    " + bttn);
			if (bttn.equals(org_otp)) {
				System.out.println("OTP verified successfully");
				response.sendRedirect("showKeypad.jsp?Numb=otp");
				// response.sendRedirect("profile.jsp");

			} else {
				System.out.println("OTP is Wrong");
				response.sendRedirect("verifyotp.jsp?Number=wrong");

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
