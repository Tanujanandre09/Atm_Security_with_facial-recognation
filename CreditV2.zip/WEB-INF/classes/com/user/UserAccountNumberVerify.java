package com.user;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dbconnection.Constants;
import com.dbconnection.DbConnection;
import com.github.sarxos.webcam.Webcam;

/**
 * Servlet implementation class UserAccountNumberVerify
 */
@WebServlet("/UserAccountNumberVerify")
public class UserAccountNumberVerify extends HttpServlet {

	private static final long serialVersionUID = 1L;

	float per;
	int countA = 0, countB = 0;
	String checkimage = "D:\\mayur.jpg";
	String nextpageimage;
	String adminimage, imagetext, admincheck;
	String year;
	String roll_no;
	Connection con = null;
	float x;
	String p;
	String name;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserAccountNumberVerify() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			String accNum = request.getParameter("accNum");
			String password = request.getParameter("password");

			Connection con = DbConnection.getConnection();

			PreparedStatement ps = con.prepareStatement(
					"select * from USERS where account_number='" + accNum + "' and password='" + password + "'");
			ResultSet rs = ps.executeQuery();

			System.out.println("1");

			if (rs.next()) {
				HttpSession sesssion = request.getSession();
				sesssion.setAttribute("userId", rs.getString("id"));
				sesssion.setAttribute("accNum", accNum);
				sesssion.setAttribute("fullname", rs.getString("fullname"));
				sesssion.setAttribute("profilePicture", rs.getString("profile_picture"));

				System.out.println("2");

				capture();

				/// call LRR

				System.out.println("Post");

				try {

					PreparedStatement ps1 = con.prepareStatement("select * from users ");
					ResultSet rs1 = ps1.executeQuery();
					while (rs1.next()) {
						System.out.println("-------------------------------------");
						adminimage = rs1.getString("profile_picture");
						imagetext = rs1.getString("profile_picture");
						String userId = rs1.getString("id");

						System.out.println(adminimage);
						System.out.println(imagetext);

						admincheck = Constants.IMAGE_FILE_PATH + adminimage;
						// System.out.println(admincheck);

						System.out.println(" files  : " + checkimage + " : " + admincheck);

						LRR lrr = new LRR();
						float l = lrr.compareimage(checkimage, admincheck);

						System.out.println(l);

						PreparedStatement ps6 = con.prepareStatement("update users set mvalue=? where id = ? ");
						ps6.setString(1, String.valueOf(l));
						ps6.setString(2, userId);
						ps6.executeUpdate();

					} // -----------------------------end of
						// while----------------------------

					PreparedStatement ps7 = con.prepareStatement("select max(mvalue) as per from users ");
					ResultSet rs7 = ps7.executeQuery();
					while (rs7.next()) {
						per = rs7.getFloat("per");
					}

					HttpSession session = request.getSession();

					String detectedUserId = "";
					PreparedStatement ps8 = con.prepareStatement("select * from users where mvalue=?");
					ps8.setFloat(1, per);
					ResultSet rs8 = ps8.executeQuery();
					while (rs8.next()) {
						detectedUserId = rs8.getString("id");
						System.out.println("diseaseId =" + detectedUserId);
						// response.sendRedirect("nameretrive.jsp");
					}

					String userId = session.getAttribute("userId").toString();

					if (per > 60 && detectedUserId.equalsIgnoreCase(userId)) {

						response.sendRedirect("CaptureFace.jsp?AccVerified=1");

						// response.sendRedirect("CustomerHome.jsp?tracationSuccess");
					}

					response.sendRedirect("CaptureFace.jsp?AccVerified=1");

					//response.sendRedirect("CustomerHome.jsp?incorrectFace");

				} catch (Exception e) {
					e.printStackTrace();
				}

				// LRR ends

				System.out.println("3");
				// response.sendRedirect("CaptureFace.jsp?AccVerified=1");
			} else {
				response.sendRedirect("CustomerHome.jsp?incorrectAccNum");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void capture() {
		try {

			// BufferedImage image = new Robot()
			// .createScreenCapture(new
			// Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			// ImageIO.write(image, "png", new File("D://screenshot.png"));

			Webcam webcam = Webcam.getDefault();
			webcam.open();
			ImageIO.write(webcam.getImage(), "PNG", new File("D:\\WebTest111.jpg"));

			Thread.sleep(5000);
			/*
			 * SendAttachmentInEmail s = new
			 * SendAttachmentInEmail();//D:\\WebTest.png
			 * s.EmailSending("lambatesunny@gmail.com", "Test", "Test",
			 * "D:\\screenshot.png","D:\\WebTest.png");
			 */
			webcam.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
