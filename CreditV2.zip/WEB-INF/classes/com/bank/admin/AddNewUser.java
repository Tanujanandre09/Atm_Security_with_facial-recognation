package com.bank.admin;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.dbconnection.Constants;
import com.dbconnection.DbConnection;

/**
 * Servlet implementation class AddNewUser
 */
@WebServlet("/AddNewUser")
public class AddNewUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddNewUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	Connection con = null;
	PreparedStatement ps;
	ResultSet rs;
	String fileName, fullname, dob, gender, address, email, mobile_number, aadhar, password;

	// image settings
	private static final int THRESHOLD_SIZE = 1024 * 1024 * 3; // 3MB
	private static final int MAX_FILE_SIZE = 1024 * 1024 * 40; // 40MB
	private static final int REQUEST_SIZE = 1024 * 1024 * 50; // 50MB
	private List<FileItem> fileItem = null;

	protected List<FileItem> initRequest(HttpServletRequest req) {
		boolean isMultipart = ServletFileUpload.isMultipartContent(req);
		if (!isMultipart)
			throw new UnsupportedOperationException();
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(THRESHOLD_SIZE);
		factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(MAX_FILE_SIZE);
		upload.setSizeMax(REQUEST_SIZE);
		List<FileItem> formItems = null;
		try {
			formItems = upload.parseRequest(req);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return formItems;
	}

	public void init() {

		try {

			con = DbConnection.getConnection();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	protected String getFieldValue(List<FileItem> formItems, String fieldName) {
		String value = null;
		try {
			for (FileItem fi : formItems) {
				if (fi.isFormField()) {
					if (fi.getFieldName().equals(fieldName)) {
						value = fi.getString();
					}
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return value;
	}

	protected File uploadFile(List<FileItem> formItems, String destFolder) {
		String uploadPath = destFolder;
		File uploadDir = new File(uploadPath);
		if (!uploadDir.exists()) {
			uploadDir.mkdir();
		}
		File uploadedFile = null;
		try {
			for (FileItem fi : formItems) {
				if (!fi.isFormField()) {
					String fileName = new File(fi.getName()).getName();
					String filePath = uploadPath + File.separator + fileName;
					uploadedFile = new File(filePath);
					fi.write(uploadedFile);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return uploadedFile;

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try

		{
			fileItem = initRequest(request);
			File file = uploadFile(fileItem, Constants.IMAGE_FILE_PATH + "WebContent\\profile_pictures\\");

			fullname = getFieldValue(fileItem, "fullname");
			address = getFieldValue(fileItem, "address");
			dob = getFieldValue(fileItem, "dob");
			gender = getFieldValue(fileItem, "gender");
			email = getFieldValue(fileItem, "email");
			mobile_number = getFieldValue(fileItem, "mobile");
			aadhar = getFieldValue(fileItem, "aadhar");
			password = getFieldValue(fileItem, "password");
			String accNum  = getFieldValue(fileItem, "accountNumber");
			fileName = file.getName();

			String addedAt = "";
			System.out.println("user details Name is " + fullname + ", " + address + ", " + dob + ", " + gender + ", "
					+ email + ", " + mobile_number + ", " + aadhar + ", " + password);
			System.out.println("Image fileName is " + fileName);

			PrintWriter out = response.getWriter();

			PreparedStatement pst = con.prepareStatement("SELECT COUNT(id) as count FROM users ");

			ResultSet res = pst.executeQuery();

			int accountNumber = Constants.accountNumber;
			if (res.next()) {
				accountNumber = Integer.parseInt(res.getString("count")) + 1;
			}
			System.out.println("aa : "+accountNumber);
			
			ps = con.prepareStatement("INSERT INTO `users`(`fullname`, `address`, `dob`, `gender`, `aadhar`, `email`,"
					+ " `mobile_number`, `password`, `profile_picture`, `added_at`, `active`, `deleted`, `account_number`)" + " VALUES ('"
					+ fullname + "','" + address + "','" + dob + "','" + gender + "','" + aadhar + "','" + email + "',"
					+ "'" + mobile_number + "','" + password + "','" + fileName + "','" + addedAt + "',true,false, '"+accNum+"')");

			int result = ps.executeUpdate();

			if (result > 0) {
				out.println("<html>");
				out.println("<body>");
				out.println("<center>");
				out.println("<h1>User added sucsessfully </h1>");
				out.println("<h4 style='color:red'><a href=ViewUsers.jsp>back</a></h4>");

				out.println("<center>");
				out.println("</body>");
				out.println("</html>");

			} else {
				out.println("<html>");
				out.println("<body>");
				out.println("<center>");
				out.println("<h1>Image Already Present</h1>");
				out.println("<center>");
				out.println("</body>");
				out.println("</html>");

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void distroy() {

		try {
			ps.close();
			con.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

}
