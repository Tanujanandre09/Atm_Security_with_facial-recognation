package com.bank.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dbconnection.DbConnection;

/**
 * Servlet implementation class AddBalance
 */
@WebServlet("/AddBalance")
public class AddBalance extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddBalance() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {

			String amount = request.getParameter("amount");

			HttpSession session = request.getSession();

			String userId = request.getParameter("user_id");

			System.out.println("amt : " + amount + " user : " + userId);

			System.out.println("userId : " + session.getAttribute("userid"));

			if (amount == "0") {
				response.sendRedirect("ViewUsers.jsp?incorrectAmount");
			}

			if (Integer.parseInt(amount) <= 0) {
				response.sendRedirect("ViewUsers.jsp?incorrectAmount");
			}

			Connection con = DbConnection.getConnection();

			PreparedStatement ps = con.prepareStatement("INSERT INTO `user_transactions` "
					+ "(`user_id`, `transaction_type`, `added_at`, `amount`, `status`, `transaction_by`) " + "VALUES ('"
					+ session.getAttribute("userid") + "','CREDIT', ' ', '" + amount + "', 'SUCCESS', 'ADMIN')");
			int rs = ps.executeUpdate();
			if (rs > 0) {
				HttpSession sesssion = request.getSession();
				sesssion.setAttribute("userid", userId);
				response.sendRedirect("BankAdminHome.jsp?success");
			} else {
				response.sendRedirect("BankAdmin.jsp?incorrect");
			}
		} catch (Exception e) {
			e.printStackTrace();
			// response.sendRedirect("ViewUsers.jsp?incorrectAmount");

		}
	}
}